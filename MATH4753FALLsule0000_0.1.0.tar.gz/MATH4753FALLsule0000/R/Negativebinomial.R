#' Negative Binomial
#'
#' @param y Number of trials until the rth success is observed
#' @param r Number of trials
#' @param p Probability of success of a single Bernoulli trial
#'
#' @return negative binomial
#' @export
#'
#' @examples
#' mynegbinom(6,10,0.5)
mynegbinom=function(y,r,p){
  choose(y-1,r-1)*p^r*(1-p)^(y-r)
}
