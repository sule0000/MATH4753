#' A simple Function
#'
#' @param x A quantitative data
#'
#' @return list
#' @export
#'
#' @examples
#' myread(3:10)
myread=function(x){
  list(meann = mean(x)^2)
}
