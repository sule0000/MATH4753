#' Fire
#'
#' Dataset of distance and damgae of fires
#'
#'
#' @format ## `fire`
#' A data frame with 7,240 rows and 60 columns:
#' \describe{
#'   \item{Distance}{Distance of fire}
#'   \item{Damhge}{Damge that fire caused}
#'   ...
#' }
#'
"fire"
