#' A simple Function
#'
#' @param x A quantitative data
#'
#' @return A list containing mean squared
#' @export
#'
#' @examples
#' myread(x = 1:4)
myread=function(x){
  list(meann = mean(x)^2)
}
