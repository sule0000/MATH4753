#' Normal curve
#'
#' @param mu The mean of the data
#' @param sigma The standard deviation of the data
#' @param a The right bound
#'
#' @return Normal curve
#' @export
#'
#' @examples
#' myncurve(mu=6,sigma=4,a=2)
myncurve = function(mu, sigma, a){
  x=seq(mu-3*sigma, mu+3*sigma,length.out = 1000)
  curve(dnorm(x,mean=mu,sd=sigma),
        xlim = c(mu-3*sigma, mu + 3*sigma),
        ylab=paste('norm  mean:', mu,'  sd:', sigma))
  xcurve=seq(mu-3*sigma, a,length=1000)
  ycurve=dnorm(xcurve,mean=mu,sd=sigma)
  polygon(c(mu-3*sigma,xcurve,a),c(0,ycurve,0),col="Red")
  cat('Prob:',round(pnorm(a, mean= mu, sd= sigma), 4))
}

