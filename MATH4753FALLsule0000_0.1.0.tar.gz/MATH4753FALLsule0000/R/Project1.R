#' Title Flight overbooking
#'
#' @param N Number of seat on flight
#' @param gamma probability of overbooking
#' @param p probability of passenger showing
#'
#' @return 2 plot and a list
#' @export
#'
#' @examples
#' ntickets( N = 400 , gamma = 0.02, p = 0.95)
ntickets <- function(N = 200, gamma = 0.02, p = 0.95){

  layout(matrix(1:2, nr = 2, nc = 1, byrow = TRUE))
  n <- seq(N, floor(N + N/10), by = 1)
  tmp <- 1 - gamma - pbinom(N, n, p)

  q= 1-p

  fn <- abs(tmp)
 nd <- data.frame(fn)
 nd <- round(nd, 2)
 min <- which.min(nd$fn)
 ticket = (N-1) + min
 plot(nd$fn~n, type = "b", pch = 21, bg ="Blue") + abline(v =ticket, h = 0, col = "red", title(main = "Objective vs n Discrete"))


 nd = ticket

 n <- seq(N, floor(N + N/10), by = 1)
 nc <- data.frame(fn = abs(1 - gamma - pnorm(N, n*p, sqrt(n*p*q))))
 nc <- round(nc, 2)
 min <- which.min(nc$fn)
 ticket = (N-1) + min
 plot(nc$fn~n, type = "l") + abline(v =ticket, h = 0, col = "blue", title(main = "Objective vs n Continuous"))

 nc = ticket

 data = list(nd, nc, N, p, gamma)

 }



